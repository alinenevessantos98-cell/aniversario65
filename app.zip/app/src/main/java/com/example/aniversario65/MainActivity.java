package com.example.aniversario65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu);


        findViewById(R.id.button2).setOnClickListener(v -> {
            startActivity(new Intent(this, ConvidadosActivity.class));
        });


        findViewById(R.id.button3).setOnClickListener(v -> {
            startActivity(new Intent(this, GastosActivity.class));
        });


        findViewById(R.id.button4).setOnClickListener(v -> {
            startActivity(new Intent(this, ComidasActivity.class));
        });
    }
}