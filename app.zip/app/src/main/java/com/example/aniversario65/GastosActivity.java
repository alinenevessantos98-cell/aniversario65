package com.example.aniversario65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class GastosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gastos);


        EditText edtValor1 = findViewById(R.id.edtValor1);
        EditText edtValor2 = findViewById(R.id.edtValor2);


        Button btnCalcular = findViewById(R.id.btnCalcularGastos);
        Button btnVoltar = findViewById(R.id.btnVoltarGastos);


        TextView txtResultado = findViewById(R.id.txtResultadoGastos);


        btnCalcular.setOnClickListener(v -> {
            String valor1Str = edtValor1.getText().toString();
            String valor2Str = edtValor2.getText().toString();

            if (!valor1Str.isEmpty() && !valor2Str.isEmpty()) {
                double valor1 = Double.parseDouble(valor1Str);
                double valor2 = Double.parseDouble(valor2Str);

                double total = valor1 + valor2;
                txtResultado.setText("Total: R$ " + total);
            } else {
                txtResultado.setText("Preencha os dois valores");
            }
        });


        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(GastosActivity.this, MenuActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
