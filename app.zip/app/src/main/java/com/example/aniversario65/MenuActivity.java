package com.example.aniversario65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        AlertDialog.Builder aviso = new AlertDialog.Builder(this);
        aviso.setTitle("Sobre o Aplicativo");
        aviso.setMessage(
                "Este aplicativo foi desenvolvido para auxiliar na organização " +
                        "de uma festa de aniversário de 65 anos. Ele permite controlar " +
                        "a lista de convidados, os gastos da festa e as comidas."
        );
        aviso.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        aviso.show();


        Button btnMenu = findViewById(R.id.btnMenu);
        btnMenu.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}
