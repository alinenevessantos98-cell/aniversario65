package com.example.aniversario65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ComidasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comidas);


        TextView textLista = findViewById(R.id.textListaComidas);
        EditText edtNovaComida = findViewById(R.id.edtNovaComida);
        Button btnAdicionar = findViewById(R.id.btnAdicionarComida);
        Button btnVoltar = findViewById(R.id.btnVoltarMenu);


        btnAdicionar.setOnClickListener(v -> {
            String comida = edtNovaComida.getText().toString();

            if (!comida.isEmpty()) {
                textLista.setText(textLista.getText() + "\n" + comida);
                edtNovaComida.setText("");
            }
        });


        btnVoltar.setOnClickListener(v -> {
            startActivity(new Intent(this, MenuActivity.class));
            finish();
        });
    }
}
