package com.example.aniversario65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConvidadosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_convidados);


        EditText edtNovoConvidado = findViewById(R.id.edtNovoConvidado);
        Button btnAdicionar = findViewById(R.id.btnAdicionarConvidado);
        TextView textLista = findViewById(R.id.textListaConvidados);
        Button btnVoltar = findViewById(R.id.btnVoltarMenu);


        btnAdicionar.setOnClickListener(v -> {
            String nome = edtNovoConvidado.getText().toString();

            if (!nome.isEmpty()) {
                textLista.setText(textLista.getText() + "\n" + nome);
                edtNovoConvidado.setText("");
            }
        });


        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(ConvidadosActivity.this, MenuActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
